#(c)2020, karneliuk.com

__version__ = '0.3.2'