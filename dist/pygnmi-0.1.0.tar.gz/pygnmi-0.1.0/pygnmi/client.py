#!/usr/bin/env python
# (c)2020, karneliuk.com

# Modules

# Classes
class gNMIclient(object):
    """
    This class is used to communicate with the network functions over gRPC with gNMI specification.
    Python 3.7 and gNMI 0.7.0 is tested.
    """
    def __init__(self):
        pass


# CLI tool
if __name__ == "__main__":
    pass