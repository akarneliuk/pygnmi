==========================
pyGNMI: Python gNMI client
==========================
This repository contains pure Python implementation of the gNMI client to interact with the network functions.

=====
Usage
=====
The explanation of the demo:

Supported requests
------------------
- Capabilities

Supported operation modes
-------------------------
- insecure gRPC channel (without encryption)

Tested network operating systems (NOS)
--------------------------------------
- Arista EOS
- Nokia SRLinux

=======
License
=======
By using the pyGNMI tool you agree with `the license <LICENSE.txt>`_.

=======
Dev Log
=======
Release **0.1.1**:

- Added the ``Get`` operation out of gNMI specification.

Release **0.1.0**:

- The first release.